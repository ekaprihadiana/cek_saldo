<?php

use Illuminate\Support\Facades\DB;

Route::get('/cek-db', function () {
    try {
        $data = DB::select("SELECT * FROM users LIMIT 1");
        return response()->json([
            'status' => 'success',
            'message' => 'Koneksi database berhasil',
            'data' => $data
        ]);
    } catch (\Exception $e) {
        return response()->json([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
});